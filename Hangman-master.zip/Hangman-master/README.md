# Hangman-Python
A simple hangman game made with python and pygame. This was made as a beginner pygame project in grade 11 (2017).

# Requirements
- Python 3.x
- pygame

# Run in GitPod

You can also run Hnagman in Gitpod, a free online dev environment for GitHub:

If you're intersted in a paid subscription with GitPod use the coupon code: **TECHWITHTIM19**

[![Open in Gitpod](https://gitpod.io/button/open-in-gitpod.svg)](https://gitpod.io/#https://github.com/techwithtim/Hangman/blob/master/hangman.py)
