'''
imports the essentials needed for the game to actually begin,
this is what is executed once you double click that run button
'''
from library import loading_screen
from library import launcher_screen
